package com.example;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Funcionario {

    public static void inserirFuncionario(Scanner scanner, Connection conn) {
        System.out.println("Inserir novo funcionário");
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Cargo: ");
        String cargo = scanner.nextLine();
        System.out.print("Salário: ");
        double salario = scanner.nextDouble();
        scanner.nextLine(); // Consumir a quebra de linha

        String sql = "INSERT INTO funcionarios (nome, cargo, salario) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.setString(2, cargo);
            stmt.setDouble(3, salario);
            stmt.executeUpdate();
            System.out.println("Funcionário inserido com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void atualizarFuncionario(Scanner scanner, Connection conn) {
        System.out.println("Atualizar funcionário");
        System.out.print("ID do funcionário: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir a quebra de linha
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Cargo: ");
        String cargo = scanner.nextLine();
        System.out.print("Salário: ");
        double salario = scanner.nextDouble();
        scanner.nextLine(); // Consumir a quebra de linha

        String sql = "UPDATE funcionarios SET nome = ?, cargo = ?, salario = ? WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.setString(2, cargo);
            stmt.setDouble(3, salario);
            stmt.setInt(4, id);
            stmt.executeUpdate();
            System.out.println("Funcionário atualizado com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void excluirFuncionario(Scanner scanner, Connection conn) {
        System.out.println("Excluir funcionário");
        System.out.print("ID do funcionário: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir a quebra de linha

        String sql = "DELETE FROM funcionarios WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            stmt.executeUpdate();
            System.out.println("Funcionário excluído com sucesso!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void listarFuncionarios(Connection conn) {
        System.out.println("Listar funcionários");

        String sql = "SELECT * FROM funcionarios";

        try (PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String cargo = rs.getString("cargo");
                double salario = rs.getDouble("salario");
                System.out.println("ID: " + id + ", Nome: " + nome + ", Cargo: " + cargo + ", Salário: " + salario);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
