package com.example;

import java.sql.*;
import java.util.Scanner;

public class TipoQuarto {
    public static void inserirTipoQuarto(Scanner scanner, Connection conn) {
        System.out.print("Tipo: ");
        String tipo = scanner.nextLine();
        System.out.print("Descrição: ");
        String descricao = scanner.nextLine();
        System.out.print("Preço: ");
        double preco = scanner.nextDouble();
        scanner.nextLine(); // Consumir a quebra de linha

        String sql = "INSERT INTO tipos_quarto (tipo, descricao, preco) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, tipo);
            stmt.setString(2, descricao);
            stmt.setDouble(3, preco);
            stmt.executeUpdate();
            System.out.println("Tipo de quarto inserido com sucesso.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void atualizarTipoQuarto(Scanner scanner, Connection conn) {
        System.out.print("ID do Tipo de Quarto a atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir a quebra de linha

        System.out.print("Novo Tipo: ");
        String tipo = scanner.nextLine();
        System.out.print("Nova Descrição: ");
        String descricao = scanner.nextLine();
        System.out.print("Novo Preço: ");
        double preco = scanner.nextDouble();
        scanner.nextLine(); // Consumir a quebra de linha

        String sql = "UPDATE tipos_quarto SET tipo = ?, descricao = ?, preco = ? WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, tipo);
            stmt.setString(2, descricao);
            stmt.setDouble(3, preco);
            stmt.setInt(4, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Tipo de quarto atualizado com sucesso.");
            } else {
                System.out.println("Tipo de quarto não encontrado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void excluirTipoQuarto(Scanner scanner, Connection conn) {
        System.out.print("ID do Tipo de Quarto a excluir: ");
        int id = scanner.nextInt();

        String sql = "DELETE FROM tipos_quarto WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Tipo de quarto excluído com sucesso.");
            } else {
                System.out.println("Tipo de quarto não encontrado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void listarTiposQuarto(Connection conn) {
        String sql = "SELECT * FROM tipos_quarto";

        try (Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String tipo = rs.getString("tipo");
                String descricao = rs.getString("descricao");
                double preco = rs.getDouble("preco");

                System.out.printf("ID: %d, Tipo: %s, Descrição: %s, Preço: %.2f%n", id, tipo, descricao, preco);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}