package com.example;

import java.sql.*;
import java.util.Scanner;

public class Hospede {
    public static void inserirHospede(Scanner scanner, Connection conn) {
        System.out.print("Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Endereço: ");
        String endereco = scanner.nextLine();
        System.out.print("Telefone: ");
        String telefone = scanner.nextLine();

        String sql = "INSERT INTO hospedes (nome, endereco, telefone) VALUES (?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.setString(2, endereco);
            stmt.setString(3, telefone);
            stmt.executeUpdate();
            System.out.println("Hóspede inserido com sucesso.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void atualizarHospede(Scanner scanner, Connection conn) {
        System.out.print("ID do Hóspede a atualizar: ");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir a quebra de linha

        System.out.print("Novo Nome: ");
        String nome = scanner.nextLine();
        System.out.print("Novo Endereço: ");
        String endereco = scanner.nextLine();
        System.out.print("Novo Telefone: ");
        String telefone = scanner.nextLine();

        String sql = "UPDATE hospedes SET nome = ?, endereco = ?, telefone = ? WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, nome);
            stmt.setString(2, endereco);
            stmt.setString(3, telefone);
            stmt.setInt(4, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Hóspede atualizado com sucesso.");
            } else {
                System.out.println("Hóspede não encontrado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void excluirHospede(Scanner scanner, Connection conn) {
        System.out.print("ID do Hóspede a excluir: ");
        int id = scanner.nextInt();

        String sql = "DELETE FROM hospedes WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Hóspede excluído com sucesso.");
            } else {
                System.out.println("Hóspede não encontrado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void listarHospedes(Connection conn) {
        String sql = "SELECT * FROM hospedes";

        try (Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String nome = rs.getString("nome");
                String endereco = rs.getString("endereco");
                String telefone = rs.getString("telefone");

                System.out.printf("ID: %d, Nome: %s, Endereço: %s, Telefone: %s%n", id, nome, endereco, telefone);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}