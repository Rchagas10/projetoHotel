package com.example;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.Scanner;

public class App {
    public static void main(String[] args) {
        try (Connection conn = DatabaseConnection.conectar();
                Scanner scanner = new Scanner(System.in)) {

            if (conn == null) {
                System.out.println("Não foi possível estabelecer uma conexão com o banco de dados.");
                return;
            }

            while (true) {
                System.out.println("Bem-vindo ao hotel javaBancoPost");
                System.out.println("1. Hóspedes");
                System.out.println("2. Funcionários");
                System.out.println("3. Reservas");
                System.out.println("4. Tipos de Quarto");
                System.out.println("0. Sair");
                System.out.print("Escolha uma opção: ");

                int opcao = getIntInput(scanner);

                if (opcao == 0) {
                    break;
                }

                switch (opcao) {
                    case 1:
                        menuHospedes(scanner, conn);
                        break;
                    case 2:
                        menuFuncionarios(scanner, conn);
                        break;
                    case 3:
                        menuReservas(scanner, conn);
                        break;
                    case 4:
                        menuTiposQuarto(scanner, conn);
                        break;
                    default:
                        System.out.println("Opção inválida. Tente novamente.");
                        break;
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static int getIntInput(Scanner scanner) {
        while (!scanner.hasNextInt()) {
            System.out.println("Entrada inválida. Por favor, insira um número inteiro.");
            scanner.next(); // Descartar a entrada inválida
        }
        int input = scanner.nextInt();
        scanner.nextLine(); // Consumir a quebra de linha
        return input;
    }

    private static void menuHospedes(Scanner scanner, Connection conn) {
        while (true) {
            System.out.println("Menu Hóspedes");
            System.out.println("1. Inserir Hóspede");
            System.out.println("2. Atualizar Hóspede");
            System.out.println("3. Excluir Hóspede");
            System.out.println("4. Listar Hóspedes");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");

            int opcao = getIntInput(scanner);

            if (opcao == 0) {
                break;
            }

            switch (opcao) {
                case 1:
                    Hospede.inserirHospede(scanner, conn);
                    break;
                case 2:
                    Hospede.atualizarHospede(scanner, conn);
                    break;
                case 3:
                    Hospede.excluirHospede(scanner, conn);
                    break;
                case 4:
                    Hospede.listarHospedes(conn);
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        }
    }

    private static void menuFuncionarios(Scanner scanner, Connection conn) {
        while (true) {
            System.out.println("Menu Funcionários");
            System.out.println("1. Inserir Funcionário");
            System.out.println("2. Atualizar Funcionário");
            System.out.println("3. Excluir Funcionário");
            System.out.println("4. Listar Funcionários");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");

            int opcao = getIntInput(scanner);

            if (opcao == 0) {
                break;
            }

            switch (opcao) {
                case 1:
                    Funcionario.inserirFuncionario(scanner, conn);
                    break;
                case 2:
                    Funcionario.atualizarFuncionario(scanner, conn);
                    break;
                case 3:
                    Funcionario.excluirFuncionario(scanner, conn);
                    break;
                case 4:
                    Funcionario.listarFuncionarios(conn);
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        }
    }

    private static void menuReservas(Scanner scanner, Connection conn) {
        while (true) {
            System.out.println("Menu Reservas");
            System.out.println("1. Inserir Reserva");
            System.out.println("2. Atualizar Reserva");
            System.out.println("3. Excluir Reserva");
            System.out.println("4. Listar Reservas");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");

            int opcao = getIntInput(scanner);

            if (opcao == 0) {
                break;
            }

            switch (opcao) {
                case 1:
                    Reserva.inserirReserva(scanner, conn);
                    break;
                case 2:
                    Reserva.atualizarReserva(scanner, conn);
                    break;
                case 3:
                    Reserva.excluirReserva(scanner, conn);
                    break;
                case 4:
                    Reserva.listarReservas(conn);
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        }
    }

    private static void menuTiposQuarto(Scanner scanner, Connection conn) {
        while (true) {
            System.out.println("Menu Tipos de Quarto");
            System.out.println("1. Inserir Tipo de Quarto");
            System.out.println("2. Atualizar Tipo de Quarto");
            System.out.println("3. Excluir Tipo de Quarto");
            System.out.println("4. Listar Tipos de Quarto");
            System.out.println("0. Voltar");
            System.out.print("Escolha uma opção: ");

            int opcao = getIntInput(scanner);

            if (opcao == 0) {
                break;
            }

            switch (opcao) {
                case 1:
                    TipoQuarto.inserirTipoQuarto(scanner, conn);
                    break;
                case 2:
                    TipoQuarto.atualizarTipoQuarto(scanner, conn);
                    break;
                case 3:
                    TipoQuarto.excluirTipoQuarto(scanner, conn);
                    break;
                case 4:
                    TipoQuarto.listarTiposQuarto(conn);
                    break;
                default:
                    System.out.println("Opção inválida. Tente novamente.");
                    break;
            }
        }
    }
}