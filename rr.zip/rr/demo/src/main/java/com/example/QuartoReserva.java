package com.example;

import java.sql.*;
import java.util.Scanner;

public class QuartoReserva {
    public static void inserirQuartoReserva(Scanner scanner, Connection conn) {
        System.out.print("ID da Reserva: ");
        int reservaId = scanner.nextInt();
        System.out.print("ID do Tipo de Quarto: ");
        int tipoQuarto = scanner.nextInt();
        scanner.nextLine(); // Consumir a quebra de linha

        String sql = "INSERT INTO quarto_reserva (reserva_id, tipo_quarto) VALUES (?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, reservaId);
            stmt.setInt(2, tipoQuarto);
            stmt.executeUpdate();
            System.out.println("Quarto na reserva inserido com sucesso.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void atualizarQuartoReserva(Scanner scanner, Connection conn) {
        System.out.print("ID do Quarto na Reserva a atualizar: ");
        int id = scanner.nextInt();
        System.out.print("Novo ID da Reserva: ");
        int reservaId = scanner.nextInt();
        System.out.print("Novo ID do Tipo de Quarto: ");
        int tipoQuarto = scanner.nextInt();
        scanner.nextLine(); // Consumir a quebra de linha

        String sql = "UPDATE quarto_reserva SET reserva_id = ?, tipo_quarto = ? WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, reservaId);
            stmt.setInt(2, tipoQuarto);
            stmt.setInt(3, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Quarto na reserva atualizado com sucesso.");
            } else {
                System.out.println("Quarto na reserva não encontrado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void excluirQuartoReserva(Scanner scanner, Connection conn) {
        System.out.print("ID do Quarto na Reserva a excluir: ");
        int id = scanner.nextInt();

        String sql = "DELETE FROM quarto_reserva WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Quarto na reserva excluído com sucesso.");
            } else {
                System.out.println("Quarto na reserva não encontrado.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void listarQuartosReserva(Connection conn) {
        String sql = "SELECT * FROM quarto_reserva";

        try (Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                int reservaId = rs.getInt("reserva_id");
                int tipoQuarto = rs.getInt("tipo_quarto");

                System.out.printf("ID: %d, ID Reserva: %d, ID Tipo de Quarto: %d%n", id, reservaId, tipoQuarto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}