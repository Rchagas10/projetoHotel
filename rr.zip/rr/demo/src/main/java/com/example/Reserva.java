package com.example;

import java.sql.*;
import java.util.Scanner;

public class Reserva {
    public static void inserirReserva(Scanner scanner, Connection conn) {
        System.out.print("ID do Hóspede: ");
        int idHospede = scanner.nextInt();
        System.out.print("ID do Quarto: ");
        int idQuarto = scanner.nextInt();
        System.out.print("ID do Funcionário: ");
        int idFuncionario = scanner.nextInt();
        System.out.print("Data de Início (YYYY-MM-DD): ");
        String dataInicio = scanner.next();
        System.out.print("Data de Fim (YYYY-MM-DD): ");
        String dataFim = scanner.next();
        scanner.nextLine(); // Consumir a quebra de linha
        System.out.print("Status: ");
        String status = scanner.nextLine();

        String sql = "INSERT INTO reservas (id_hospede, id_quarto, id_funcionario, data_inicio, data_fim, status) VALUES (?, ?, ?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idHospede);
            stmt.setInt(2, idQuarto);
            stmt.setInt(3, idFuncionario);
            stmt.setDate(4, Date.valueOf(dataInicio));
            stmt.setDate(5, Date.valueOf(dataFim));
            stmt.setString(6, status);
            stmt.executeUpdate();
            System.out.println("Reserva inserida com sucesso.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void atualizarReserva(Scanner scanner, Connection conn) {
        System.out.print("ID da Reserva a atualizar: ");
        int id = scanner.nextInt();
        System.out.print("Novo ID do Hóspede: ");
        int idHospede = scanner.nextInt();
        System.out.print("Novo ID do Quarto: ");
        int idQuarto = scanner.nextInt();
        System.out.print("Novo ID do Funcionário: ");
        int idFuncionario = scanner.nextInt();
        System.out.print("Nova Data de Início (YYYY-MM-DD): ");
        String dataInicio = scanner.next();
        System.out.print("Nova Data de Fim (YYYY-MM-DD): ");
        String dataFim = scanner.next();
        scanner.nextLine(); // Consumir a quebra de linha
        System.out.print("Novo Status: ");
        String status = scanner.nextLine();

        String sql = "UPDATE reservas SET id_hospede = ?, id_quarto = ?, id_funcionario = ?, data_inicio = ?, data_fim = ?, status = ? WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idHospede);
            stmt.setInt(2, idQuarto);
            stmt.setInt(3, idFuncionario);
            stmt.setDate(4, Date.valueOf(dataInicio));
            stmt.setDate(5, Date.valueOf(dataFim));
            stmt.setString(6, status);
            stmt.setInt(7, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Reserva atualizada com sucesso.");
            } else {
                System.out.println("Reserva não encontrada.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void excluirReserva(Scanner scanner, Connection conn) {
        System.out.print("ID da Reserva a excluir: ");
        int id = scanner.nextInt();

        String sql = "DELETE FROM reservas WHERE id = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, id);
            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Reserva excluída com sucesso.");
            } else {
                System.out.println("Reserva não encontrada.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void listarReservas(Connection conn) {
        String sql = "SELECT * FROM reservas";

        try (Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                int id = rs.getInt("id");
                int idHospede = rs.getInt("id_hospede");
                int idQuarto = rs.getInt("id_quarto");
                int idFuncionario = rs.getInt("id_funcionario");
                Date dataInicio = rs.getDate("data_inicio");
                Date dataFim = rs.getDate("data_fim");
                String status = rs.getString("status");

                System.out.printf(
                        "ID: %d, ID Hóspede: %d, ID Quarto: %d, ID Funcionário: %d, Data Início: %s, Data Fim: %s, Status: %s%n",
                        id, idHospede, idQuarto, idFuncionario, dataInicio, dataFim, status);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}